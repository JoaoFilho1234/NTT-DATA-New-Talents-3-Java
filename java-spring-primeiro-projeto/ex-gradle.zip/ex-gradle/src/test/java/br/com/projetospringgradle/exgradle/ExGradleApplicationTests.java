package br.com.projetospringgradle.exgradle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExGradleApplicationTests {

	@Test
	void contextLoads() {
	}

}
