package br.com.projetospringgradle.exgradle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExGradleApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExGradleApplication.class, args);
	}

}
