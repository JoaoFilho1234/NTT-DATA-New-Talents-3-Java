package br.com.projetospringmaven.exmaven;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExMavenApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExMavenApplication.class, args);
	}

}
