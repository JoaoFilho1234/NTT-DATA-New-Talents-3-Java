package br.com.blogjava.exmaven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExMavenApplicationTests {

	@Test
	void contextLoads() {
	}

}
